""" Env Initialization"""
from os import environ

GCS_TRAINING_DATA = environ["GCS_TRAINING_DATA"]
GCS_VALIDATION_DATA = environ["GCS_VALIDATION_DATA"]
GCS_MODEL_DATA_PATH = environ["GCS_MODEL_DATA_PATH"]